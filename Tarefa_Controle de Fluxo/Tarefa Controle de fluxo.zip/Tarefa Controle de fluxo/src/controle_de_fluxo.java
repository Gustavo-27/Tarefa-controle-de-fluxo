import java.util.Scanner;

public class controle_de_fluxo {


        public static void main(String args[]) {
            Scanner s = new Scanner(System.in);
            System.out.println("Digite a nota do aluno");
            int result = s.nextInt();
            if (result >= 7) {
                System.out.println("Aprovado");
            } else if (result >= 5) {
                System.out.println("Recuperação");
            } else {
                System.out.println("Reprovado");
            }
        }

    }


